import { Student } from './students';

describe('Students', () => {
  it('should create an instance', () => {
    expect(new Student()).toBeTruthy();
  });
});
